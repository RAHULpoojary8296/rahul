const socket = io();
let localStream;
let peerConnection;

const startCallButton = document.getElementById('startCall');
const hangUpButton = document.getElementById('hangUp');

startCallButton.addEventListener('click', startCall);
hangUpButton.addEventListener('click', hangUp);

async function startCall() {
    localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    peerConnection = new RTCPeerConnection();
    
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            socket.emit('signal', { candidate: event.candidate });
        }
    };

    peerConnection.ontrack = event => {
        const audioElement = document.createElement('audio');
        audioElement.srcObject = event.streams[0];
        audioElement.autoplay = true;
    };

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    
    socket.emit('signal', { offer });
    startCallButton.disabled = true;
    hangUpButton.disabled = false;
}

socket.on('signal', async data => {
    if (data.offer) {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);
        socket.emit('signal', { answer });
    }

    if (data.answer) {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
    }

    if (data.candidate) {
        await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
    }
});

function hangUp() {
    peerConnection.close();
    localStream.getTracks().forEach(track => track.stop());
    startCallButton.disabled = false;
    hangUpButton.disabled = true;
}
